﻿using BulkyBook.DataAccess.Repository.IRepository;
using BulkyBook.Models;
using Microsoft.AspNetCore.Mvc;

namespace BulkyBookWeb.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CoverTypeController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public CoverTypeController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            IEnumerable<CoverType> objectCoverTypeList = _unitOfWork.CoverType.GetAll();

            return View(objectCoverTypeList);
        }

        /// <summary>
        /// Get action
        /// </summary>
        /// <returns></returns>
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Post action
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CoverType obj)
        {
            //if (obj.Name == obj.DisplayOrder.ToString())
            //{
            //    ModelState.AddModelError("name", "The DisplayOrder can't exactly match the Name.");
            //}

            if (ModelState.IsValid)
            {
                _unitOfWork.CoverType.Add(obj);

                _unitOfWork.Save();

                TempData["success"] = "Cover type created successfully";

                return RedirectToAction("Index");
            }

            return View(obj);
        }

        /// <summary>
        /// Edit action
        /// </summary>
        /// <returns></returns>
        public IActionResult Edit(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var coverTypeFromDb = _unitOfWork.CoverType.GetFirstOrDefault(c => c.Id.Equals(id));

            //var categoryFromDbFirst = _db.Categories.FirstOrDefault(c => c.Id.Equals(id));

            if (coverTypeFromDb == null)
            {
                return NotFound();
            }

            return View(coverTypeFromDb);

        }

        /// <summary>
        /// Post action
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(CoverType obj)
        {
            //if (obj.Name == obj.DisplayOrder.ToString())
            //{
            //    ModelState.AddModelError("name", "The DisplayOrder can't exactly match the Name.");
            //}

            if (ModelState.IsValid)
            {
                _unitOfWork.CoverType.Update(obj);

                _unitOfWork.Save();

                TempData["success"] = "Cover type updated successfully";

                return RedirectToAction("Index");
            }

            return View(obj);
        }


        /// <summary>
        /// Delete action
        /// </summary>
        /// <returns></returns>
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var coverTypeFromDb = _unitOfWork.CoverType.GetFirstOrDefault(c => c.Id.Equals(id));

            if (coverTypeFromDb == null)
            {
                return NotFound();
            }

            return View(coverTypeFromDb);

        }

        /// <summary>
        /// Post action
        /// </summary>
        /// <returns></returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var obj = _unitOfWork.CoverType.GetFirstOrDefault(c => c.Id.Equals(id));

            if (id == null)
            {
                return NotFound();
            }

            _unitOfWork.CoverType.Remove(obj);

            _unitOfWork.Save();

            TempData["success"] = "Cover type deleted successfully";

            return RedirectToAction("Index");
        }
    }
}
