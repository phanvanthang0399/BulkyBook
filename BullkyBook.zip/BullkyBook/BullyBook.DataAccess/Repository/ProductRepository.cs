﻿using BulkyBook.DataAccess.Data;
using BulkyBook.DataAccess.Repository.IRepository;
using BulkyBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.DataAccess.Repository
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public ProductRepository(ApplicationDbContext db) : base(db)
        {

        }

        public void Update(Product product)
        {
            var getProductFromDb = dbSet.FirstOrDefault(p => p.Id.Equals(product.Id));

            if (getProductFromDb != null)
            {
                getProductFromDb.Title = product.Title;
                getProductFromDb.ISBN = product.ISBN;
                getProductFromDb.Price = product.Price;
                getProductFromDb.Price50 = product.Price50;
                getProductFromDb.Price100 = product.Price100;
                getProductFromDb.ListPrice = product.ListPrice;
                getProductFromDb.Description = product.Description;
                getProductFromDb.CategoryId = product.CategoryId;
                getProductFromDb.Author = product.Author;
                getProductFromDb.CoverTypeId = product.CoverTypeId;

                if (product.ImageUrl != null)
                {
                    getProductFromDb.ImageUrl = product.ImageUrl;
                }
            }
        }
    }
}
